package com.nova.client;

public final class NovaConfig {
    public static boolean coordinatesHud = true;
    public static boolean waypointManager = true;
    public static boolean minimalHud = true;

    private NovaConfig() {}
}
