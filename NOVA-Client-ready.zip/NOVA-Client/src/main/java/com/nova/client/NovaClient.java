package com.nova.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class NovaClient implements ClientModInitializer {
    public static final List<String> WAYPOINTS = new ArrayList<>();

    private KeyBinding openMenu;
    private KeyBinding addWaypoint;

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.nova.menu",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.nova"
        ));

        addWaypoint = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.nova.waypoint",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_P,
            "category.nova"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                client.setScreen(new NovaScreen());
            }
            while (addWaypoint.wasPressed()) {
                addCurrentWaypoint(client);
            }
        });

        HudRenderCallback.EVENT.register((draw, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || !NovaConfig.coordinatesHud) return;

            int x = (int) client.player.getX();
            int y = (int) client.player.getY();
            int z = (int) client.player.getZ();

            if (NovaConfig.minimalHud) {
                draw.fill(8, 8, 165, 48, 0xB0101010);
            }

            draw.drawTextWithShadow(
                client.textRenderer, "NOVA CLIENT", 15, 14, 0xFFEAEAEA
            );
            draw.drawTextWithShadow(
                client.textRenderer, "XYZ: " + x + " / " + y + " / " + z,
                15, 29, 0xFFFFFFFF
            );
        });
    }

    public static void addCurrentWaypoint(MinecraftClient client) {
        if (client.player == null || !NovaConfig.waypointManager) return;

        String point = String.format(
            "Waypoint %d: %d, %d, %d",
            WAYPOINTS.size() + 1,
            (int) client.player.getX(),
            (int) client.player.getY(),
            (int) client.player.getZ()
        );
        WAYPOINTS.add(point);
        client.player.sendMessage(Text.literal("[NOVA] Saved: " + point), false);
    }
}
