package com.nova.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class NovaScreen extends Screen {
    private static final int PANEL = 0xF0121212;
    private static final int BORDER = 0xFF414141;
    private static final int WHITE = 0xFFEAEAEA;
    private static final int MUTED = 0xFF999999;

    public NovaScreen() {
        super(Text.literal("NOVA Client"));
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int top = Math.max(12, height / 2 - 112);

        addDrawableChild(ButtonWidget.builder(
            moduleLabel("Coordinates HUD", NovaConfig.coordinatesHud),
            button -> {
                NovaConfig.coordinatesHud = !NovaConfig.coordinatesHud;
                refreshMenu();
            }
        ).dimensions(cx - 100, top + 48, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(
            moduleLabel("Waypoint Manager", NovaConfig.waypointManager),
            button -> {
                NovaConfig.waypointManager = !NovaConfig.waypointManager;
                refreshMenu();
            }
        ).dimensions(cx - 100, top + 75, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(
            moduleLabel("Minimal HUD", NovaConfig.minimalHud),
            button -> {
                NovaConfig.minimalHud = !NovaConfig.minimalHud;
                refreshMenu();
            }
        ).dimensions(cx - 100, top + 102, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(
            Text.literal("Add Current Waypoint"),
            button -> NovaClient.addCurrentWaypoint(client)
        ).dimensions(cx - 100, top + 135, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(
            Text.literal("Close"),
            button -> close()
        ).dimensions(cx - 100, top + 166, 200, 20).build());
    }

    private Text moduleLabel(String name, boolean enabled) {
        return Text.literal(name + "  [" + (enabled ? "ON" : "OFF") + "]");
    }

    private void refreshMenu() {
        if (client != null) client.setScreen(new NovaScreen());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);

        int cx = width / 2;
        int top = Math.max(12, height / 2 - 112);

        context.fill(cx - 115, top, cx + 115, top + 202, PANEL);
        context.fill(cx - 115, top, cx + 115, top + 1, BORDER);

        context.drawCenteredTextWithShadow(
            textRenderer, Text.literal("N O V A"), cx, top + 10, WHITE
        );
        context.drawCenteredTextWithShadow(
            textRenderer, Text.literal("CLIENT / MODULES"), cx, top + 28, MUTED
        );
        context.drawCenteredTextWithShadow(
            textRenderer,
            Text.literal("Right Shift: open menu  |  P: waypoint"),
            cx, top + 188, MUTED
        );

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
