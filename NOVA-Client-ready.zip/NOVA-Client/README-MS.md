# NOVA Client — Fabric 1.21.1

Mod client asas dengan:
- HUD koordinat XYZ
- ClickGUI minimalis hitam/kelabu
- Right Shift untuk membuka menu
- P untuk menyimpan waypoint sementara
- Suis ON/OFF untuk modul

## Keperluan
- Minecraft Java Edition 1.21.1
- Java/JDK 21
- Fabric Loader
- Fabric API

## Bina JAR
Pada Windows, buka PowerShell dalam folder projek dan jalankan:

```powershell
.\gradlew.bat build
```

Pada macOS/Linux:

```bash
./gradlew build
```

JAR yang dibina biasanya berada dalam `build/libs/`.

## Build melalui GitHub Actions (jika tiada Gradle di PC)
1. Muat naik projek ini ke repository GitHub sendiri.
2. Buka tab **Actions** dan jalankan workflow **Build NOVA Client**.
3. Selepas selesai, muat turun artifact `nova-client-jar` daripada run tersebut.

Workflow memerlukan akses internet untuk memuat turun dependency Fabric/Gradle.

## Pasang
Salin JAR hasil binaan ke folder `mods` bagi profil Fabric Minecraft 1.21.1.

## Nota
ZIP ini mengandungi kod sumber dan fail projek, bukan JAR yang telah disahkan berjaya dikompilasi. Gradle Wrapper tidak dibundel; gunakan Gradle yang dipasang atau workflow GitHub Actions yang disertakan. Waypoint dalam versi ini disimpan dalam memori sahaja dan hilang apabila permainan ditutup.

Mod ini untuk koordinat dan lokasi yang ditanda sendiri. Ia tidak mengesan base tersembunyi atau memintas mekanik server.
